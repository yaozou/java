package com.example.ftp.demo;



import org.apache.ftpserver.ftplet.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Date;

@Configuration
public class FtpService extends DefaultFtplet {
    @Value("${server.port}")
    private Integer port;
    @Value("${server.host}")
    private String host;



    @Override
    public FtpletResult onUploadEnd(FtpSession session, FtpRequest request)
            throws FtpException, IOException {
        String path = session.getFileSystemView().getWorkingDirectory().getAbsolutePath();//获取当前路径
        String[] picInfoArr = session.getFileSystemView().getWorkingDirectory().getAbsolutePath().split("/");
        String filename = request.getArgument();//获取文件名
        InetSocketAddress serverAddress = session.getServerAddress();

        return super.onUploadEnd(session, request);
    }

    @Override
    public FtpletResult onUploadStart(FtpSession session, FtpRequest request)
            throws FtpException, IOException {
        String path = session.getFileSystemView().getWorkingDirectory().getAbsolutePath();//获取当前路径
        String rootPath = session.getUser().getHomeDirectory();//获取根目录绝对路径
        String filename = request.getArgument();//获取文件名
        return super.onUploadStart(session, request);
    }
}
