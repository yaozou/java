package com.example.ftp.demo;

public class Constants {
    public static final String SERVER_NAME="FTP-SERVER";
}
