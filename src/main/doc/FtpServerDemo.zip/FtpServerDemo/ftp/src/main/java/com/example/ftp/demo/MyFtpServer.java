package com.example.ftp.demo;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.ftpserver.DataConnectionConfiguration;
import org.apache.ftpserver.DataConnectionConfigurationFactory;
import org.apache.ftpserver.FtpServer;
import org.apache.ftpserver.FtpServerFactory;
import org.apache.ftpserver.ftplet.FtpException;
import org.apache.ftpserver.ftplet.Ftplet;
import org.apache.ftpserver.listener.Listener;
import org.apache.ftpserver.listener.ListenerFactory;
import org.apache.ftpserver.ssl.SslConfiguration;
import org.apache.ftpserver.usermanager.ClearTextPasswordEncryptor;
import org.apache.ftpserver.usermanager.PropertiesUserManagerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class MyFtpServer {
    @Autowired
    FtpService service;
    FtpServer server = null;
    private Map<String, Ftplet> ftpLets = new HashMap<>();

    public void initFtp() throws URISyntaxException, IOException {
        FtpServerFactory serverFactory = new FtpServerFactory();
        ListenerFactory listenerFactory = new ListenerFactory();
        // replacethedefault listener
        listenerFactory.setPort(3131);
        DataConnectionConfigurationFactory dataConnectionConfFactory = new DataConnectionConfigurationFactory();
        dataConnectionConfFactory.setPassivePorts("10000-10100");
        listenerFactory.setDataConnectionConfiguration(dataConnectionConfFactory.createDataConnectionConfiguration());
        Listener listener = listenerFactory.createListener();
        serverFactory.addListener("default", listener);
//        FtpService ftpService = new FtpService();
        ftpLets.put("ftpService", service);
        serverFactory.setFtplets(ftpLets);
        PropertiesUserManagerFactory userManagerFactory = new PropertiesUserManagerFactory();
        String tempPath = System.getProperty("java.io.tmpdir") + System.currentTimeMillis() + ".properties";
        File tempConfig = new File(tempPath);
        log.info("users.properties目录临时存储路径" + tempPath);

        ClassPathResource resource = new ClassPathResource("properties/users.properties");
//        InputStream inputStream = resource.getInputStream();
        IOUtils.copy(resource.getInputStream(), new FileOutputStream(tempConfig));
//        File ftpConfig = ResourceUtils.getFile(ResourceUtils.CLASSPATH_URL_PREFIX + "properties/users.properties");
//        File file = new File("users.properties");
        userManagerFactory.setFile(tempConfig);
        userManagerFactory.setPasswordEncryptor(new ClearTextPasswordEncryptor());
        serverFactory.setUserManager(userManagerFactory.createUserManager());
        server = serverFactory.createServer();

    }

    public void start() {
        try {
            server.start();
            System.out.println("FTP Start");
        } catch (FtpException e) {
            e.printStackTrace();
        }
    }

    public void stop() {
        server.stop();
        System.out.println("FTP Stop");
    }

    /**
     * getActiveLocalAddress = null
     getPassiveAddress = null
     getPassivePorts = 0
     getPassiveExernalAddress = null
     getActiveLocalPort = 0
     getIdleTime = 300
     getSslConfiguration = null
     isActiveEnabled = true
     isActiveIpCheck = false
     isImplicitSsl = false
     requestPassivePort = 0
     */
    private DataConnectionConfiguration dataConnectionConfiguration = new DataConnectionConfiguration() {
        @Override
        public int getIdleTime() {
            return 0;
        }

        @Override
        public boolean isActiveEnabled() {
            return false;
        }

        @Override
        public boolean isActiveIpCheck() {
            return false;
        }

        @Override
        public String getActiveLocalAddress() {
            return null;
        }

        @Override
        public int getActiveLocalPort() {
            return 0;
        }

        @Override
        public String getPassiveAddress() {
            return null;
        }

        @Override
        public String getPassiveExernalAddress() {
            return null;
        }

        @Override
        public String getPassivePorts() {
            return "400-9000";
        }

        @Override
        public int requestPassivePort() {
            return 0;
        }

        @Override
        public void releasePassivePort(int i) {

        }

        @Override
        public SslConfiguration getSslConfiguration() {
            return null;
        }

        @Override
        public boolean isImplicitSsl() {
            return false;
        }
    };
}